package com.Ixia.payments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayementsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
