package com.Ixia.payments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PayementsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PayementsServiceApplication.class, args);
	}

}
