package com.ixia.checkoutservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CheckoutServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
